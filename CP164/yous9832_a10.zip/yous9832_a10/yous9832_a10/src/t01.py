"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Antoine Youssef
ID:      169069832
Email:   yous9832@mylaurier.ca
__updated__ = "2024-03-30"
-------------------------------------------------------
"""
from Sorts_array import Sorts

a = [1, 1000, 3, 999, 5, 6, 7, 88, 4, 2]

Sorts.radix_sort(a)

print(a)
