"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Antoine Youssef
ID:      169069832
Email:   yous9832@mylaurier.ca
__updated__ = "2024-02-02"
-------------------------------------------------------
"""

from Food import Food

key = Food("NAHHH", 6, None, 250)

print(key)
