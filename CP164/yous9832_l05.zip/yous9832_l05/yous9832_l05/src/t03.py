"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Antoine Youssef
ID:      169069832
Email:   yous9832@mylaurier.ca
__updated__ = "2024-02-09"
-------------------------------------------------------
"""

from functions import vowel_count

# Example usage
text = "b a e i o u"
print(f"The amount of vowels in '{text}' is {vowel_count(text)}")
