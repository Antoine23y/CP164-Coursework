"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Antoine Youssef
ID:      169069832
Email:   yous9832@mylaurier.ca
__updated__ = "2024-02-09"
-------------------------------------------------------
"""
from functions import recurse

x_value = 3
y_value = 2

result = recurse(x_value, y_value)

print(f"The result of recurse({x_value}, {y_value}) is {result}")
